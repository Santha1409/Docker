let initialState2 = {
  

  questions : [

    {
      "DISPLAYSEQ": "1",
      "QUESTIONID": "330011",
      "ROLE": "Manager",
      "FORM": "SL33 Daily Manager Check",
      "SECTION": "Weekly Checks",
      "TYPE": "OK",
      "TEXT": "All country of origin and date codes are correct and clearly displayed on loose produce",
      "STATUS": "TODO",
      "NEXTSTEPS": [ { "id": 1, "notes": "HI this is vinod", "assigned": "vinod", "initials": "hulloli", "date": "24 May 2017 15:45", "snextstep": "Security"}]
    },
    {
      "DISPLAYSEQ": "2",
      "QUESTIONID": "330012",
      "ROLE": "Manager",
      "FORM": "SL33 Daily Manager Check",
      "SECTION": "Weekly Checks",
      "TYPE": "OK",
      "TEXT": "A potential reductions report is produced and followed on a daily basis",
      "STATUS": "GREEN",
      "NEXTSTEPS": []
    },
    {
      "DISPLAYSEQ": "3",
      "QUESTIONID": "330013",
      "ROLE": "Manager",
      "FORM": "SL33 Daily Manager Check",
      "SECTION": "Weekly Checks",
      "TYPE": "OK",
      "TEXT": "All country of origin and date codes are correct and clearly displayed on loose produce",
      "STATUS": "TODO",
      "NEXTSTEPS": []
    },
    {
      "DISPLAYSEQ": "4",
      "QUESTIONID": "330014",
      "ROLE": "Manager",
      "FORM": "SL33 Daily Manager Check",
      "SECTION": "Weekly Checks",
      "TYPE": "OK",
      "TEXT": "A potential reductions report is produced and followed on a daily basis",
      "STATUS": "GREEN",
      "NEXTSTEPS": []
    }
  ]

};

export default initialState2;

//
// let initialState2 = {
//
//   questions : [
//
//     {
//       qno : 1
//     },
//
//     {
//       qno : 2
//     },
//
//     {
//       qno : 3
//     },
//
//     {
//       qno : 4
//     }
//
//   ]
//
// };










// let initialState = {
//
//   "questions" : [
//
//     {
//       "qno" : 1,
//       "answers" : [
//         "answer 1",
//         "answer 2",
//         "answer 3",
//         "answer 4"
//       ]
//     },
//
//     {
//       "qno" : 2,
//       "answers" : [
//         "answer 1",
//         "answer 2",
//         "answer 3",
//         "answer 4"
//       ]
//     },
//
//     {
//       "qno" : 3,
//       "answers" : [
//         "answer 1",
//         "answer 2",
//         "answer 3",
//         "answer 4"
//       ]
//     },
//
//     {
//       "qno" : 4,
//       "answers" : [
//         "answer 1",
//         "answer 2",
//         "answer 3",
//         "answer 4"
//       ]
//     }
//
//   ]
//
// };
//
