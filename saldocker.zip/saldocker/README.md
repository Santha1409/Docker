

To get started, first install all the necessary dependencies.
```
> npm install
```

Run an initial webpack build
```
> npm run build
```

Start the development server (changes will now update live in browser)
```
> npm start
```

To view your project, go to: [http://localhost:3000/]
