import 'babel-polyfill';
import React from 'react';
import ReactDOM from "react-dom";

import App2 from './App2';
//import LoginNew from './components/new/Login';


ReactDOM.render(
    <App2 />,
    document.getElementById('root')
);
