
import React from 'react';
import Profile from './Profile';

class Login extends React.Component {

  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      submit : false
    };
  }

  handleSubmit(e) {
    e.preventDefault();

    const formData = {};
    for (const field in this.refs) {
      formData[field] = this.refs[field].value;
    }

    this.setState({submit : true});
    //console.log('-->', formData);
  }

  render() {
    var form = ( <Form1 onSubmit={this.handleSubmit}/> );
    var profile = ( <Profile /> );
    return (
        <div className="container">


<header role="banner" >
  <div className="global-header">
    <div className="topwrapper">
        <a href="http://localhost:3000"> <img style={{width:"156px", margin:"10px 10px 20px 0px"}} src="../../assets/img/tesco.svg"/> </a>
    </div>
  </div>
</header>

          { this.state.submit ? profile : form }


          <footer role="contentinfo" className="nopadtop" style={{marginTop:"100px", marginLeft:"-20px"}}>
             <div className="footer">

                <div className="container">
                 <div className="row">
                  <div className="col-md-12 col-sm-12 col-xs-12">

                   <div className="col-xs-12 col-sm-6">
                   <div className="col-sm-12 col-xs-12 col-md-6">
    				              <img src="../../assets/img/help.svg" alt="Every little helps" width="156" height="70" />
                   </div>

                   <div className="col-sm-12 col-xs-12 col-md-4">
                      <p><strong>Helpdesk</strong></p>
                      <p>UK Dial-In: 99999</p>
                      <p>UK Long Dial-In: 999</p>
                   </div>
    		           <div className="col-sm-12">
                        <p>COPYRIGHTS </p>
                   </div>

                   </div>

                   <div className="col-xs-12 col-sm-6">
                    <p>Links</p>
                   </div>


                  </div>
                  </div>
                </div>

             </div>
          </footer>

        </div>
    );
  }

}

export default Login;


//<h1> MENU - TESCO - STORE </h1>

class Form1 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {

    return (
      <div>
<div class="utility_bar" >
       <div class="container container-0">
          <div class="col-sm-12">
             &nbsp;
          </div>
       </div>
    </div>
    <main role="main"  className="nopadbottom">
 <div className="container">
<div className="col-sm-12">
<div className="row" >
<div className="col-sm-12 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4 signin_shadow">
<div className="row" >
<div className="col-xs-12 col-sm-12 col-md-offset-2 col-md-10" >
<div className="col-xs-12 col-sm-12" >
<h4 className="signin_mobile" >Sign in</h4>
</div>
</div>
</div>
<div className="row">
<div className="col-xs-12 col-sm-12 stay-in-touch" >


<div className="col-xs-12 col-sm-12 stay-in-touch-form"  >
<form className="stay-in-touch-form" onSubmit={this.props.onSubmit}>
<div className="row"><p>
<div className="col-xs-12 col-sm-12"><label >User Name</label></div>
<div className="col-xs-12 col-sm-12"><input ref="username" type="text" name="username" /></div></p>
</div>
<div className="row"><p>
<div className="col-xs-12 col-sm-12"><label >Password</label></div></p>
<p><div className="col-xs-12 col-sm-12"><input ref="password" type="password" name="password" /></div></p>
</div>

<div className="row">
<p></p>
<p>
<div className="col-sm-12"><input  type="submit" value="Submit" /></div>
</p>
</div>

</form>

</div>

</div>

</div>
</div>
</div>

</div>
</div>
</main>
</div>
    );

  }
}






// <div className="stay-in-touch">
//   <form className="stay-in-touch-form" onSubmit={this.props.onSubmit}>
//     <input ref="username"  type='text' name="username"/>
//     <input ref="password"  type='password' name="password"/>
//     <input type="submit" value="Submit"/>
//   </form>
// </div>
