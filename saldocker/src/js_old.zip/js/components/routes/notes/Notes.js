import React from 'react';
import styles from './notes.css';

class Notes extends React.Component {

   constructor(props) {
     super(props);
   }

   render() {
      return (
        <div className="row">
         <div className="col-md-12 tnote">
            <h3> Note </h3>
            <p> {this.props.content}</p>
         </div>
        </div>
      )
   }
}

export default Notes;

//style={{border: "1px solid black", margin: "10px"}}

Notes.defaultProps = { content: "note1" };
