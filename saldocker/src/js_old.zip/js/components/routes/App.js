import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';

class App extends React.Component {
   render() {
      return (

      <div className="row">

         <div className="mainnav col-md-12 col-sm-12">
            <h4> COMPLIANCE </h4>
            <ul>
             <li> <Link to="/checks">Checks</Link> </li>
             <li> <Link to="/instr">Instructions</Link> </li>
             <li> <Link to="/notes">Notes</Link> </li>
             <li> <Link to="/details">Details</Link> </li>
            </ul>
          </div>

          <div className="row">
            <div className="col-md-6">
              {this.props.children}
            </div>
          </div>

        </div>
      )
   }
}

export default App;

//
// <Link to="/checks">Checks</Link>
// <Link to="/instr">Instructions</Link>
// <Link to="/notes">Notes</Link>
// <Link to="/details">Details</Link>

// <li to="/checks">Checks</li>
// <li to="/instr">Instructions</li>
// <li to="/notes">Notes</li>
// <li to="/details">Details</li>
