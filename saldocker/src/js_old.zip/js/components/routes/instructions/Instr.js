import React from 'react';

class Instr extends React.Component {
   render() {
      return (
         <div>
            <h6>About DR. RAJKUMAR</h6>
            <p style={{textAlign: "justify"}}>
              Singanalluru Puttaswamayya Muthuraju (24 April 1929 – 12 April 2006),[2] known mononymously by his stage name Rajkumar, was an Indian actor and singer in the Kannada cinema. Widely acclaimed as one of the finest actors in the history of Indian Cinema, he is considered a cultural icon, and holds a matinée idol status in the Kannada diaspora,[3][4] among who, he is popularly adulated as Nata Saarvabhouma (Emperor of Actors), Bangarada Manushya (Man of Gold), Vara Nata (Gifted Actor) and Rajanna (Brother Raj).[5][6]

              A method actor, Rajkumar entered the film industry after his long stint as a dramatist with Gubbi Veeranna's Gubbi Drama Company, which he joined at the age of eight, and got his first break as a lead in the 1954 film Bedara Kannappa.[6] He went on to work in over 220 films essaying a variety of roles, and excelling in portraying mythological and historical characters in films such as Bhakta Kanakadasa (1960), Ranadheera Kanteerava (1960), Satya Harishchandra (1965), Immadi Pulikeshi (1967), Sri Krishnadevaraya (1970), Bhakta Kumbara (1974), Mayura (1975) and Babruvahana (1977) and Bhakta Prahlada (1983).[7] Trained in classical music during his theatre days, Rajkumar also became an accomplished singer in Kannada cinema and despite imperfections in Shruti and pitch, he came to be known for his diction in the language. He mostly sang for his own films since 1974. The songs "Yaare Koogadali", "Huttidare Kannada", "Hey Dinakara" and "Naadamaya" became widely popular. For his rendition of the latter song, he was awarded the National Film Award for Best Male Playback Singer. Well known for his highly disciplined and simple lifestyle in both personal and professional fronts, Rajkumar was also an avid Yoga, Pranayama and Carnatic music performer. In 2000, he was kidnapped from his farm house at Gajanur by Veerappan and was released after 108 days.[8] His final screen appearance came in Jogi in 2005. He died of cardiac arrest at his residence in Bangalore on 12 April 2006 at the age of 77.[9]

              In his film career, Rajkumar received eleven Karnataka State Film Awards, ten South Filmfare Awards, one National Film Award.[10] He received the NTR National Award in 2002. He was awarded an honorary doctorate from the University of Mysore,[11] and is a recipient of the Padma Bhushan[12] in 1983 and the Dadasaheb Phalke Award in 1995 for the lifetime contribution to Indian Cinema.[13]
            </p>
         </div>
      )
   }
}

export default Instr;
