export const getQuestions = (bookid) => {
    console.log("Get Questions for Book_Id: ", bookid);
    return {
        type: 'GET_QUESTIONS',
        payload: bookid
    }
};

export const updateQuestions = (qid) => {
    console.log("Update Questions for Book_Id: ", qid);
    return {
        type: 'UPDATE_QUESTIONS',
        payload: qid
    }
};

export const addNextStepForQ = (qid, data) => {
    console.log("NextStep for Question : ", qid);
    console.log("data: "+data);
    return {
        type: 'ADD_NEXT_STEP',
        qid: qid,
        data: data
    }
};

export const editNextStepForQ = (qid, nid, data) => {
    console.log("Edit NextStep for Question : ", qid, nid);
    console.log("data: "+data);
    return {
        type: 'EDIT_NEXT_STEP',
        qid: qid,
        nid: nid,
        data: data
    }
};


export const changeStatusForQ = (qid) => {
    console.log("Change Status for Question : ", qid);
    return {
        type: 'CHANGE_STATUS',
        qid: qid
    }
};




export const addQuestions = (bookid) => {
    console.log("Add Questions for Book_Id: ", bookid);
    return {
        type: 'ADD_QUESTIONS',
        payload: bookid,
        data:        {
                        "qno" : 5,
                        "answers" : [
                          "answer 1",
                          "answer 2",
                          "answer 3",
                          "answer 4"
                        ]
                      }
    }
};

export const addItem = (item) => {
    console.log("Add item: ", item.brand);
    return {
        type: 'ADD_ITEM',
        payload: item
    }
};

export const removeItem = (index) => {
    console.log("Delete item with index: ", index);
    return {
        type: 'DELETE_ITEM',
        payload: index
    }
};
